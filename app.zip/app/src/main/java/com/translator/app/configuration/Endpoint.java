package com.translator.app.configuration;

import com.translator.app.endpoint.handler.IEndpointHandler;
import com.translator.app.endpoint.router.IEndpointRouter;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

@Configuration
@AllArgsConstructor
public class Endpoint {

    private IEndpointHandler<ServerRequest, ServerResponse> translatorHandler;
    private IEndpointRouter<IEndpointHandler<ServerRequest,ServerResponse>, ServerResponse> translatorRouter;

    @Bean
    public RouterFunction<ServerResponse> translatorRouterEndPoint(){
        return translatorRouter.route(translatorHandler);
    }

}
