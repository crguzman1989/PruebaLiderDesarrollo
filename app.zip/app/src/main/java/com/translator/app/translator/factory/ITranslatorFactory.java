package com.translator.app.translator.factory;

import com.translator.app.translator.component.ITranslator;

public interface ITranslatorFactory {
    <T> ITranslator<T> getTranslator(String translatorType);
}
