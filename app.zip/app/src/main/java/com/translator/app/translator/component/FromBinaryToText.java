package com.translator.app.translator.component;

import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
public class FromBinaryToText implements ITranslator<String>{
    @Override
    public Mono<String> translate(String text) {
        return null;
    }
}
