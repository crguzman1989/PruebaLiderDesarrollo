package com.translator.app.endpoint.handler;

import com.translator.app.pojo.Request;
import com.translator.app.pojo.Response;
import com.translator.app.process.IProcess;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

@Component
@AllArgsConstructor
public class TranslatorHandler implements IEndpointHandler<ServerRequest, ServerResponse>{

    private IProcess<Request, Response> translationProcess;

    @Override
    public Mono<ServerResponse> execute(ServerRequest request) {
        return request.bodyToMono(Request.class)
                .flatMap(req -> translationProcess.process(req))
                .flatMap(res -> ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).bodyValue(res));
    }
}
