package com.translator.app.process;

import com.translator.app.pojo.Request;
import com.translator.app.pojo.Response;
import com.translator.app.translator.factory.ITranslatorFactory;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@AllArgsConstructor
public class TranslationProcess implements IProcess<Request, Response>{

    private ITranslatorFactory translatorFactory;

    @Override
    public Mono<Response> process(Request processRequest) {
        return Mono.just(processRequest)
                .map(request -> translatorFactory.getTranslator(request.getOriginFormat().concat("_").concat(request.getDestinyFormat())))
                .flatMap(translator -> translator.translate(processRequest.getTex()))
                .flatMap(translation -> Mono.just(new Response(translation.toString())));
    }
}
