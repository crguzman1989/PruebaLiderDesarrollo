package com.translator.app.parser.component;

import reactor.core.publisher.Mono;

public interface IParse<T, U> {
    Mono<U> parse(T input);
}
