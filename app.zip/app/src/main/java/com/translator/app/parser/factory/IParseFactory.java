package com.translator.app.parser.factory;

public interface IParseFactory <T, U>{

}
