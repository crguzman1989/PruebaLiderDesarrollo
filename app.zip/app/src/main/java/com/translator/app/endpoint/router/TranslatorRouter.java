package com.translator.app.endpoint.router;

import com.translator.app.endpoint.handler.IEndpointHandler;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.*;

@Component
public class TranslatorRouter implements IEndpointRouter<IEndpointHandler<ServerRequest, ServerResponse>, ServerResponse>{
    @Override
    public RouterFunction<ServerResponse> route(IEndpointHandler<ServerRequest, ServerResponse> handler) {
        return RouterFunctions.route(RequestPredicates.POST("translate").and(RequestPredicates.accept(MediaType.APPLICATION_JSON)),handler:: execute);
    }
}
