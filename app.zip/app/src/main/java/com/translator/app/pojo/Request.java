package com.translator.app.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "tex",
        "originFormat",
        "destinyFormat",
})

public class Request {
    @JsonProperty("text")
    private  String tex;
    @JsonProperty("originFormat")
    private String originFormat;
    @JsonProperty("destinyFormat")
    private String destinyFormat;
}
