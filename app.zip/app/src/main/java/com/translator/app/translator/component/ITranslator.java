package com.translator.app.translator.component;

import reactor.core.publisher.Mono;

public interface ITranslator<T> {
    Mono<T> translate(T text);
}
