package com.translator.app.translator.factory;

import com.translator.app.translator.component.ITranslator;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@AllArgsConstructor
public class TranslatorFactory implements ITranslatorFactory{

    private Map<String,ITranslator> translatorMap;

    @Override
    public <T> ITranslator<T> getTranslator(String translatorType) {
        return translatorMap.get(translatorType);
    }
}
