package com.translator.app.configuration;

import com.translator.app.translator.component.ITranslator;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@AllArgsConstructor
public class Translator {

    private ITranslator<String> fromBinaryToText;
    private ITranslator<String> fromMorseToText;
    private ITranslator<String> fromTextToBinary;
    private ITranslator<String> fromTextToMorse;

    @Bean
    public Map<String, ITranslator> translatorMap(){
        HashMap<String, ITranslator> translatorMap = new HashMap<>();

        translatorMap.put("BINARY_TEXT",fromBinaryToText);
        translatorMap.put("MORSE_TEXT",fromMorseToText);
        translatorMap.put("TEXT_BINARY",fromTextToBinary);
        translatorMap.put("TEXT_MORSE",fromTextToMorse);

        return translatorMap;
    }
}
