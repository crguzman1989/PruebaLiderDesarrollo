package com.translator.app.process;

import reactor.core.publisher.Mono;

public interface IProcess<T,U> {
    Mono<U> process(T processRequest);
}
