package com.translator.app.parser.component;

import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class FromStringToArrayCharacter implements IParse<String, ArrayList<Character>> {

    @Override
    public Mono<ArrayList<Character>> parse(String input) {
        return Mono.fromCallable(() -> input.chars()
                    .mapToObj(e -> (char) e).collect(Collectors.toCollection(ArrayList::new)))
        ;
    }
}
